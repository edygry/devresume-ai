// Background Service Worker
// Handles API calls, job discovery, premium validation

chrome.runtime.onInstalled.addListener(() => {
  console.log('[DevResume AI] Extension installed');
  
  // Set up default values
  chrome.storage.local.set({
    apiKey: '',
    isPremium: false,
    profile: null,
    jobHistory: [],
    settings: {
      autoApply: false,
      jobDiscovery: true,
      notifyOnMatch: true
    }
  });
});

// Handle messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.action) {
    case 'autoFill':
      handleAutoFill(request, sender);
      sendResponse({ status: 'processing' });
      break;
      
    case 'checkPremium':
      checkPremiumStatus().then(isPremium => {
        sendResponse({ isPremium });
      });
      break;
      
    case 'discoverJobs':
      discoverJobs(request);
      sendResponse({ status: 'discovering' });
      break;
      
    case 'saveProfile':
      saveProfile(request.profile);
      sendResponse({ status: 'saved' });
      break;
      
    case 'validateApiKey':
      validateApiKey(request.apiKey).then(valid => {
        sendResponse({ valid });
      });
      break;
  }
  
  return true; // Keep message channel open for async response
});

// Handle auto-fill requests
async function handleAutoFill(request, sender) {
  try {
    // Get user profile
    const { profile } = await chrome.storage.local.get(['profile']);
    if (!profile) {
      throw new Error('No profile found');
    }
    
    // Check if premium is required for this ATS
    const { isPremium } = await chrome.storage.local.get(['isPremium']);
    const premiumATS = ['workday', 'ashby'];
    
    if (premiumATS.includes(request.atsType) && !isPremium) {
      // Notify user they need premium
      chrome.tabs.sendMessage(sender.tab.id, {
        action: 'showPremiumRequired',
        atsType: request.atsType
      });
      return;
    }
    
    // Get API key
    const { apiKey } = await chrome.storage.local.get(['apiKey']);
    if (!apiKey) {
      throw new Error('No API key found');
    }
    
    // Send auto-fill command to content script
    chrome.tabs.sendMessage(sender.tab.id, {
      action: 'startAutoFill',
      profile: profile,
      atsType: request.atsType
    });
    
    // Log the application
    logApplication(request.atsType, request.url);
    
  } catch (error) {
    console.error('[DevResume AI] Auto-fill failed:', error);
    chrome.tabs.sendMessage(sender.tab.id, {
      action: 'showError',
      message: error.message
    });
  }
}

// Check premium status
async function checkPremiumStatus() {
  const { isPremium } = await chrome.storage.local.get(['isPremium']);
  return isPremium || false;
}

// Discover jobs
async function discoverJobs(request) {
  try {
    const { apiKey, profile } = await chrome.storage.local.get(['apiKey', 'profile']);
    if (!apiKey || !profile) {
      throw new Error('API key or profile not set');
    }
    
    // Call OpenRouter to find matching jobs
    const jobs = await findMatchingJobs(apiKey, profile);
    
    // Store discovered jobs
    chrome.storage.local.set({ discoveredJobs: jobs });
    
    // Notify user if matches found
    if (jobs.length > 0) {
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'DevResume AI - New Jobs Found!',
        message: `${jobs.length} new jobs match your profile`
      });
    }
    
  } catch (error) {
    console.error('[DevResume AI] Job discovery failed:', error);
  }
}

// Find matching jobs using AI
async function findMatchingJobs(apiKey, profile) {
  // This would call an API to find jobs matching the profile
  // For now, return empty array
  return [];
}

// Save profile
async function saveProfile(profile) {
  await chrome.storage.local.set({ profile });
}

// Validate API key
async function validateApiKey(apiKey) {
  try {
    const response = await fetch('https://openrouter.ai/api/v1/auth/key', {
      headers: {
        'Authorization': `Bearer ${apiKey}`
      }
    });
    
    return response.ok;
  } catch (error) {
    console.error('[DevResume AI] API key validation failed:', error);
    return false;
  }
}

// Log application
async function logApplication(atsType, url) {
  const { jobHistory } = await chrome.storage.local.get(['jobHistory']);
  const history = jobHistory || [];
  
  history.push({
    atsType,
    url,
    timestamp: new Date().toISOString(),
    status: 'applied'
  });
  
  // Keep only last 100 applications
  if (history.length > 100) {
    history.splice(0, history.length - 100);
  }
  
  await chrome.storage.local.set({ jobHistory: history });
}

// Set up periodic job discovery
chrome.alarms.create('jobDiscovery', { periodInMinutes: 60 });

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'jobDiscovery') {
    discoverJobs({});
  }
});
