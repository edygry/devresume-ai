// Popup JavaScript
// Handles UI interactions and communication with background script

document.addEventListener('DOMContentLoaded', () => {
  // Load saved values
  loadSavedValues();
  
  // Set up event listeners
  setupEventListeners();
});

// Load saved values from storage
async function loadSavedValues() {
  try {
    const { apiKey, profile, isPremium, jobHistory } = await chrome.storage.local.get([
      'apiKey', 'profile', 'isPremium', 'jobHistory'
    ]);
    
    // Update API key field
    if (apiKey) {
      document.getElementById('apiKey').value = apiKey;
      updateStatus('API key set', 'success');
    }
    
    // Update profile fields
    if (profile) {
      document.getElementById('firstName').value = profile.firstName || '';
      document.getElementById('lastName').value = profile.lastName || '';
      document.getElementById('email').value = profile.email || '';
      document.getElementById('phone').value = profile.phone || '';
      document.getElementById('location').value = profile.location || '';
      document.getElementById('linkedin').value = profile.linkedin || '';
      document.getElementById('portfolio').value = profile.portfolio || '';
    }
    
    // Update premium status
    if (isPremium) {
      document.getElementById('premiumStatus').className = 'status status-success';
      document.getElementById('premiumStatus').innerHTML = '<span>✅</span><span>Premium activated</span>';
      document.getElementById('upgradePremium').textContent = 'Premium Active';
      document.getElementById('upgradePremium').disabled = true;
    }
    
    // Update stats
    const history = jobHistory || [];
    document.getElementById('applicationsCount').textContent = history.length;
    
    // Calculate days active
    const installedDate = await chrome.storage.local.get(['installedDate']);
    if (installedDate.installedDate) {
      const days = Math.floor((Date.now() - installedDate.installedDate) / (1000 * 60 * 60 * 24));
      document.getElementById('daysActive').textContent = days;
    }
    
  } catch (error) {
    console.error('[DevResume AI] Failed to load saved values:', error);
  }
}

// Set up event listeners
function setupEventListeners() {
  // Save API key
  document.getElementById('saveApiKey').addEventListener('click', async () => {
    const apiKey = document.getElementById('apiKey').value.trim();
    if (!apiKey) {
      updateStatus('Please enter an API key', 'error');
      return;
    }
    
    try {
      // Validate API key
      const response = await chrome.runtime.sendMessage({
        action: 'validateApiKey',
        apiKey: apiKey
      });
      
      if (response.valid) {
        await chrome.storage.local.set({ apiKey });
        updateStatus('API key saved', 'success');
      } else {
        updateStatus('Invalid API key', 'error');
      }
    } catch (error) {
      updateStatus('Failed to validate API key', 'error');
    }
  });
  
  // Save profile
  document.getElementById('saveProfile').addEventListener('click', async () => {
    const profile = {
      firstName: document.getElementById('firstName').value.trim(),
      lastName: document.getElementById('lastName').value.trim(),
      email: document.getElementById('email').value.trim(),
      phone: document.getElementById('phone').value.trim(),
      location: document.getElementById('location').value.trim(),
      linkedin: document.getElementById('linkedin').value.trim(),
      portfolio: document.getElementById('portfolio').value.trim()
    };
    
    if (!profile.firstName || !profile.lastName || !profile.email) {
      updateStatus('Please fill in required fields', 'error');
      return;
    }
    
    try {
      await chrome.runtime.sendMessage({
        action: 'saveProfile',
        profile: profile
      });
      updateStatus('Profile saved', 'success');
    } catch (error) {
      updateStatus('Failed to save profile', 'error');
    }
  });
  
  // Upgrade premium
  document.getElementById('upgradePremium').addEventListener('click', () => {
    // Open payment page
    chrome.tabs.create({
      url: 'https://edygry.github.io/devresume-ai/#/pricing'
    });
  });
  
  // Discover jobs
  document.getElementById('discoverJobs').addEventListener('click', () => {
    chrome.runtime.sendMessage({
      action: 'discoverJobs'
    });
    updateStatus('Job discovery started', 'success');
  });
  
  // Export data
  document.getElementById('exportData').addEventListener('click', async () => {
    try {
      const { jobHistory, profile } = await chrome.storage.local.get(['jobHistory', 'profile']);
      
      const data = {
        profile: profile,
        applications: jobHistory || [],
        exportedAt: new Date().toISOString()
      };
      
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `devresume-ai-export-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
      
      updateStatus('Data exported', 'success');
    } catch (error) {
      updateStatus('Failed to export data', 'error');
    }
  });
}

// Update status display
function updateStatus(message, type) {
  const statusEl = document.getElementById('status');
  const statusText = document.getElementById('statusText');
  
  statusEl.className = `status status-${type}`;
  statusText.textContent = message;
  
  // Auto-hide after 3 seconds
  setTimeout(() => {
    statusEl.style.opacity = '0';
    statusEl.style.transition = 'opacity 0.5s';
    setTimeout(() => {
      statusEl.style.opacity = '1';
    }, 500);
  }, 3000);
}
