// Lever Auto-Fill
// Automatically fills Lever job application forms

(function() {
  'use strict';

  // Listen for auto-fill messages
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'autoFill') {
      autoFillLever();
      sendResponse({ status: 'filling' });
    }
  });

  async function autoFillLever() {
    try {
      // Get user profile from storage
      const profile = await getProfile();
      if (!profile) {
        alert('Please set up your profile in DevResume AI first');
        return;
      }

      // Show loading state
      showLoading();

      // Fill basic info
      await fillBasicInfo(profile);
      
      // Fill work experience
      await fillWorkExperience(profile);
      
      // Fill education
      await fillEducation(profile);
      
      // Fill custom questions
      await fillCustomQuestions(profile);
      
      // Upload resume
      await uploadResume(profile);
      
      // Hide loading
      hideLoading();
      
      // Show success message
      showSuccess();
      
    } catch (error) {
      console.error('[DevResume AI] Auto-fill failed:', error);
      hideLoading();
      showError(error.message);
    }
  }

  async function getProfile() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['profile', 'apiKey', 'isPremium'], (result) => {
        resolve(result.profile);
      });
    });
  }

  function showLoading() {
    const overlay = document.createElement('div');
    overlay.id = 'devresume-loading';
    overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0,0,0,0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 999999;
    `;
    overlay.innerHTML = `
      <div style="background: white; padding: 30px; border-radius: 12px; text-align: center;">
        <div class="spinner" style="width: 40px; height: 40px; border: 4px solid #e2e8f0; border-top-color: #667eea; border-radius: 50%; margin: 0 auto 15px; animation: spin 1s linear infinite;"></div>
        <p style="font-family: sans-serif; font-weight: 600;">AI is filling your application...</p>
      </div>
    `;
    document.body.appendChild(overlay);
    
    // Add spinner animation
    const style = document.createElement('style');
    style.textContent = `
      @keyframes spin {
        to { transform: rotate(360deg); }
      }
    `;
    document.head.appendChild(style);
  }

  function hideLoading() {
    const overlay = document.getElementById('devresume-loading');
    if (overlay) overlay.remove();
  }

  function showSuccess() {
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #10b981;
      color: white;
      padding: 15px 25px;
      border-radius: 8px;
      font-family: sans-serif;
      font-weight: 600;
      z-index: 999999;
      box-shadow: 0 4px 20px rgba(0,0,0,0.2);
    `;
    notification.textContent = '✅ Application auto-filled by DevResume AI!';
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.style.opacity = '0';
      notification.style.transition = 'opacity 0.5s';
      setTimeout(() => notification.remove(), 500);
    }, 3000);
  }

  function showError(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #ef4444;
      color: white;
      padding: 15px 25px;
      border-radius: 8px;
      font-family: sans-serif;
      font-weight: 600;
      z-index: 999999;
      box-shadow: 0 4px 20px rgba(0,0,0,0.2);
    `;
    notification.textContent = `❌ Auto-fill failed: ${message}`;
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.style.opacity = '0';
      notification.style.transition = 'opacity 0.5s';
      setTimeout(() => notification.remove(), 500);
    }, 3000);
  }

  // Fill basic information
  async function fillBasicInfo(profile) {
    // First name
    const firstNameField = document.querySelector('input[name="first_name"]') || 
                          document.querySelector('input[placeholder*="First"]') ||
                          document.querySelector('input[placeholder*="first"]');
    if (firstNameField && profile.firstName) {
      firstNameField.value = profile.firstName;
      firstNameField.dispatchEvent(new Event('input', { bubbles: true }));
    }

    // Last name
    const lastNameField = document.querySelector('input[name="last_name"]') || 
                         document.querySelector('input[placeholder*="Last"]') ||
                         document.querySelector('input[placeholder*="last"]');
    if (lastNameField && profile.lastName) {
      lastNameField.value = profile.lastName;
      lastNameField.dispatchEvent(new Event('input', { bubbles: true }));
    }

    // Email
    const emailField = document.querySelector('input[name="email"]') || 
                      document.querySelector('input[type="email"]') ||
                      document.querySelector('input[placeholder*="Email"]') ||
                      document.querySelector('input[placeholder*="email"]');
    if (emailField && profile.email) {
      emailField.value = profile.email;
      emailField.dispatchEvent(new Event('input', { bubbles: true }));
    }

    // Phone
    const phoneField = document.querySelector('input[name="phone"]') || 
                      document.querySelector('input[type="tel"]') ||
                      document.querySelector('input[placeholder*="Phone"]') ||
                      document.querySelector('input[placeholder*="phone"]');
    if (phoneField && profile.phone) {
      phoneField.value = profile.phone;
      phoneField.dispatchEvent(new Event('input', { bubbles: true }));
    }

    // Location
    const locationField = document.querySelector('input[name="city"]') || 
                         document.querySelector('input[placeholder*="City"]') ||
                         document.querySelector('input[placeholder*="city"]');
    if (locationField && profile.location) {
      locationField.value = profile.location;
      locationField.dispatchEvent(new Event('input', { bubbles: true }));
    }

    // LinkedIn URL
    const linkedinField = document.querySelector('input[name="linkedin"]') || 
                         document.querySelector('input[placeholder*="LinkedIn"]') ||
                         document.querySelector('input[placeholder*="linkedin"]');
    if (linkedinField && profile.linkedin) {
      linkedinField.value = profile.linkedin;
      linkedinField.dispatchEvent(new Event('input', { bubbles: true }));
    }

    // Portfolio URL
    const portfolioField = document.querySelector('input[name="portfolio"]') || 
                          document.querySelector('input[placeholder*="Portfolio"]') ||
                          document.querySelector('input[placeholder*="portfolio"]');
    if (portfolioField && profile.portfolio) {
      portfolioField.value = profile.portfolio;
      portfolioField.dispatchEvent(new Event('input', { bubbles: true }));
    }
  }

  // Fill work experience
  async function fillWorkExperience(profile) {
    if (!profile.experience || profile.experience.length === 0) return;

    // Look for work experience section
    const experienceSection = document.querySelector('.work-experience') || 
                             document.querySelector('[data-testid="work-experience"]') ||
                             document.querySelector('section:has(h2:contains("Work Experience"))');
    
    if (experienceSection) {
      // Fill first experience
      const exp = profile.experience[0];
      
      const companyField = experienceSection.querySelector('input[placeholder*="Company"]') || 
                          experienceSection.querySelector('input[placeholder*="company"]');
      if (companyField && exp.company) {
        companyField.value = exp.company;
        companyField.dispatchEvent(new Event('input', { bubbles: true }));
      }

      const titleField = experienceSection.querySelector('input[placeholder*="Title"]') || 
                        experienceSection.querySelector('input[placeholder*="title"]');
      if (titleField && exp.title) {
        titleField.value = exp.title;
        titleField.dispatchEvent(new Event('input', { bubbles: true }));
      }

      const startDate = experienceSection.querySelector('input[placeholder*="Start"]') || 
                       experienceSection.querySelector('input[placeholder*="start"]');
      if (startDate && exp.startDate) {
        startDate.value = exp.startDate;
        startDate.dispatchEvent(new Event('input', { bubbles: true }));
      }

      const endDate = experienceSection.querySelector('input[placeholder*="End"]') || 
                     experienceSection.querySelector('input[placeholder*="end"]');
      if (endDate && exp.endDate) {
        endDate.value = exp.endDate;
        endDate.dispatchEvent(new Event('input', { bubbles: true }));
      }
    }
  }

  // Fill education
  async function fillEducation(profile) {
    if (!profile.education || profile.education.length === 0) return;

    const educationSection = document.querySelector('.education') || 
                            document.querySelector('[data-testid="education"]') ||
                            document.querySelector('section:has(h2:contains("Education"))');
    
    if (educationSection) {
      const edu = profile.education[0];
      
      const schoolField = educationSection.querySelector('input[placeholder*="School"]') || 
                         educationSection.querySelector('input[placeholder*="school"]');
      if (schoolField && edu.school) {
        schoolField.value = edu.school;
        schoolField.dispatchEvent(new Event('input', { bubbles: true }));
      }

      const degreeField = educationSection.querySelector('input[placeholder*="Degree"]') || 
                         educationSection.querySelector('input[placeholder*="degree"]');
      if (degreeField && edu.degree) {
        degreeField.value = edu.degree;
        degreeField.dispatchEvent(new Event('input', { bubbles: true }));
      }

      const gradYear = educationSection.querySelector('input[placeholder*="Year"]') || 
                      educationSection.querySelector('input[placeholder*="year"]');
      if (gradYear && edu.gradYear) {
        gradYear.value = edu.gradYear;
        gradYear.dispatchEvent(new Event('input', { bubbles: true }));
      }
    }
  }

  // Fill custom questions
  async function fillCustomQuestions(profile) {
    // Get custom questions from page
    const questions = document.querySelectorAll('.question');
    
    for (const question of questions) {
      const questionText = question.querySelector('label, h3, h4')?.textContent || '';
      
      // Look for "Why do you want to work here?" type questions
      if (questionText.includes('why') || questionText.includes('interested') || questionText.includes('motivation')) {
        const textarea = question.querySelector('textarea');
        if (textarea && profile.coverLetter) {
          textarea.value = profile.coverLetter;
          textarea.dispatchEvent(new Event('input', { bubbles: true }));
        }
      }
      
      // Look for "Tell me about yourself" type questions
      if (questionText.includes('about yourself') || questionText.includes('background') || questionText.includes('experience')) {
        const textarea = question.querySelector('textarea');
        if (textarea && profile.summary) {
          textarea.value = profile.summary;
          textarea.dispatchEvent(new Event('input', { bubbles: true }));
        }
      }
    }
  }

  // Upload resume
  async function uploadResume(profile) {
    if (!profile.resumeUrl) return;

    const fileInput = document.querySelector('input[type="file"][accept*="pdf"]') || 
                     document.querySelector('input[type="file"][accept*="resume"]') ||
                     document.querySelector('input[type="file"]');
    
    if (fileInput) {
      // Create file from URL
      const response = await fetch(profile.resumeUrl);
      const blob = await response.blob();
      const file = new File([blob], 'resume.pdf', { type: 'application/pdf' });
      
      // Create data transfer
      const dataTransfer = new DataTransfer();
      dataTransfer.items.add(file);
      fileInput.files = dataTransfer.files;
      
      // Trigger change event
      fileInput.dispatchEvent(new Event('change', { bubbles: true }));
    }
  }
})();
