// ATS Detector
// Detects which ATS is being used and injects appropriate auto-fill script

(function() {
  'use strict';

  // Detect ATS type
  function detectATS() {
    const url = window.location.href;
    
    if (url.includes('boards.greenhouse.io')) {
      return 'greenhouse';
    }
    if (url.includes('jobs.lever.co')) {
      return 'lever';
    }
    if (url.includes('workday.com')) {
      return 'workday';
    }
    if (url.includes('ashbyhq.com')) {
      return 'ashby';
    }
    if (url.includes('jobvite.com')) {
      return 'jobvite';
    }
    
    return null;
  }

  // Inject auto-fill button
  function injectAutoFillButton(atsType) {
    // Create floating button
    const button = document.createElement('div');
    button.id = 'devresume-autofill-btn';
    button.style.cssText = `
      position: fixed;
      bottom: 20px;
      right: 20px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 15px 25px;
      border-radius: 30px;
      cursor: pointer;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-weight: 600;
      font-size: 14px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.2);
      z-index: 999999;
      display: flex;
      align-items: center;
      gap: 8px;
      transition: transform 0.2s;
    `;
    
    button.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
      </svg>
      Auto-Fill with DevResume AI
    `;
    
    button.addEventListener('mouseenter', () => {
      button.style.transform = 'scale(1.05)';
    });
    
    button.addEventListener('mouseleave', () => {
      button.style.transform = 'scale(1)';
    });
    
    button.addEventListener('click', () => {
      // Send message to background script
      chrome.runtime.sendMessage({
        action: 'autoFill',
        atsType: atsType,
        url: window.location.href
      });
    });
    
    document.body.appendChild(button);
    
    // Add tooltip
    const tooltip = document.createElement('div');
    tooltip.style.cssText = `
      position: fixed;
      bottom: 75px;
      right: 20px;
      background: white;
      color: #333;
      padding: 10px 15px;
      border-radius: 8px;
      font-size: 12px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
      z-index: 999998;
      max-width: 200px;
    `;
    tooltip.textContent = 'AI-powered auto-fill for job applications';
    document.body.appendChild(tooltip);
    
    // Hide tooltip after 5 seconds
    setTimeout(() => {
      tooltip.style.opacity = '0';
      tooltip.style.transition = 'opacity 0.5s';
      setTimeout(() => tooltip.remove(), 500);
    }, 5000);
  }

  // Initialize
  const atsType = detectATS();
  if (atsType) {
    console.log(`[DevResume AI] Detected ${atsType} ATS`);
    injectAutoFillButton(atsType);
  }
})();
